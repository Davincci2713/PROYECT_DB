# React Frontend (Vite) — CRUD genérico + Login

## Requisitos
- Node 18+
- npm o pnpm o yarn

## Configuración rápida
```bash
npm i
# si tu API está en otro host/puerto:
echo "VITE_API_BASE_URL=http://localhost:8080" > .env
npm run dev
```

Abrir: http://localhost:5173

## Login
El login hace POST a `/api/auth/login` y espera `{"token": "..."}` (o `jwt`/`accessToken`). El token se guarda en `localStorage`.

## Dashboard
- Configura el **Endpoint base** (ej. `/api/products`) y **Campos** (ej. `id,nombre,precio,cantidad`).
- Requiere que los items tengan `id` como clave en la tabla.
- Soporta **GET (list)**, **POST (create)**, **PUT (update)**, **DELETE (remove)**.

## Build
```bash
npm run build
npm run preview
```

## Deploy en GitHub
- Push de todo el proyecto a tu repo.
- Si usas GitHub Pages para SPA, configura `vite` base o un workflow específico.
