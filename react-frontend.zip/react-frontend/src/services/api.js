const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || ''  // '' si mismo host, o http://localhost:8080 si externo
const TOKEN_KEY = 'token'

export async function http(method, url, body, withAuth = true) {
  const headers = { 'Content-Type': 'application/json' }
  if (withAuth) {
    const t = localStorage.getItem(TOKEN_KEY)
    if (t) headers['Authorization'] = 'Bearer ' + t
  }

  const res = await fetch(API_BASE_URL + url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  })

  if (res.status === 401 && withAuth) {
    localStorage.removeItem(TOKEN_KEY)
    window.location.href = '/login'
    return
  }

  if (!res.ok) {
    const txt = await res.text()
    throw new Error(txt || ('HTTP ' + res.status))
  }

  const ct = res.headers.get('content-type') || ''
  if (ct.includes('application/json')) return res.json()
  return res.text()
}

export const api = {
  list: (endpoint) => http('GET', endpoint),
  create: (endpoint, data) => http('POST', endpoint, data),
  update: (endpointWithId, data) => http('PUT', endpointWithId, data),
  remove: (endpointWithId) => http('DELETE', endpointWithId)
}
