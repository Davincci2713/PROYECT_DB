import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { clearToken, hasToken } from '../services/auth'

export default function Layout({ children }) {
  const location = useLocation()
  const navigate = useNavigate()
  const showLogout = hasToken() && location.pathname !== '/login'

  const onLogout = (e) => {
    e.preventDefault()
    clearToken()
    navigate('/login')
  }

  return (
    <>
      <nav className="container navbar">
        <ul>
          <li><strong>App</strong></li>
        </ul>
        <ul>
          <li><Link to="/dashboard">Dashboard</Link></li>
          {showLogout && <li><a href="#" id="logoutBtn" onClick={onLogout}>Salir</a></li>}
        </ul>
      </nav>
      <main className="container">{children}</main>
      <footer className="container muted" style={{margin:'2rem auto'}}>
        <small>© 2025 — App Base (React + Vite)</small>
      </footer>
    </>
  )
}
