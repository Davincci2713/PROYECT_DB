import React, { useEffect, useState } from 'react'
import { api } from '../services/api'
import { getToken } from '../services/auth'
import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
  const [endpoint, setEndpoint] = useState('/api/items')
  const [fieldsText, setFieldsText] = useState('id,nombre,precio,cantidad')
  const [fields, setFields] = useState(['id','nombre','precio','cantidad'])
  const [rows, setRows] = useState([])
  const [current, setCurrent] = useState({})
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    if (!getToken()) navigate('/login')
  }, [navigate])

  const buildFields = () => {
    const f = fieldsText.split(',').map(s => s.trim()).filter(Boolean)
    setFields(f)
    const base = {}
    f.forEach(k => base[k] = '')
    setCurrent(base)
  }

  const load = async () => {
    setError('')
    try {
      const data = await api.list(endpoint)
      if (!Array.isArray(data)) throw new Error('La respuesta del endpoint no es un array.')
      setRows(data)
    } catch (e) {
      setError('Error cargando datos: ' + e.message)
    }
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      if (current.id) {
        await api.update(`${endpoint}/${current.id}`, current)
      } else {
        await api.create(endpoint, current)
      }
      await load()
      buildFields()
    } catch (e) {
      setError('Error guardando: ' + e.message)
    }
  }

  const onEdit = (id) => {
    const row = rows.find(r => String(r.id) === String(id))
    if (!row) return
    const copy = {}
    fields.forEach(f => copy[f] = row[f] ?? '')
    setCurrent(copy)
  }

  const onDelete = async (id) => {
    if (!confirm('¿Borrar registro ' + id + '?')) return
    setError('')
    try {
      await api.remove(`${endpoint}/${id}`)
      await load()
    } catch (e) {
      setError('Error eliminando: ' + e.message)
    }
  }

  useEffect(() => { buildFields() }, [])

  return (
    <section>
      <h2>Dashboard</h2>
      <p className="muted">CRUD genérico conectado a tu API REST. Configura el endpoint y los campos.</p>

      <details open>
        <summary><strong>Configuración del recurso</strong></summary>
        <label>Endpoint base (GET/POST):
          <input type="text" value={endpoint} onChange={e=>setEndpoint(e.target.value)} style={{width:'380px'}} />
        </label>
        <small>Ejemplos: <code>/api/products</code>, <code>/api/usuarios</code>, etc.</small><br/>
        <label>Campos (coma-separados, en orden de visualización):
          <input type="text" value={fieldsText} onChange={e=>setFieldsText(e.target.value)} style={{width:'380px'}} />
        </label>
        <button onClick={()=>{ buildFields(); load(); }}>Cargar</button>
      </details>

      <hr/>

      <article>
        <header><strong>Crear / Editar</strong></header>
        <form onSubmit={onSubmit}>
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:'8px'}}>
            {fields.map(f => (
              <label key={f}>{f}
                <input type="text" name={f} value={current[f] ?? ''}
                       onChange={e => setCurrent({...current, [f]: e.target.value})}
                       readOnly={f === 'id'} />
              </label>
            ))}
          </div>
          <div style={{display:'flex', gap:'.5rem', marginTop:'.5rem'}}>
            <button type="submit">Guardar</button>
            <button type="button" className="secondary" onClick={buildFields}>Cancelar</button>
          </div>
        </form>
      </article>

      <article className="table-scroll">
        <table>
          <thead>
            <tr>
              {fields.map(f => <th key={f}>{f}</th>)}
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id}>
                {fields.map(f => <td key={f}>{r[f] ?? ''}</td>)}
                <td>
                  <button onClick={()=>onEdit(r.id)}>Editar</button>{' '}
                  <button className="secondary" onClick={()=>onDelete(r.id)}>Borrar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </article>

      {error && <div className="error" style={{marginTop:'1rem'}}>{error}</div>}
    </section>
  )
}
