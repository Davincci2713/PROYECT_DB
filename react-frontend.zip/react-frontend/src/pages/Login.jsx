import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { setToken, getToken } from '../services/auth'
import { http } from '../services/api'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    if (getToken()) navigate('/dashboard')
  }, [navigate])

  const onSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      const res = await http('POST', '/api/auth/login', { username, password }, false)
      const token = res.token || res.jwt || res.accessToken
      if (!token) throw new Error('La respuesta no contiene token.')
      setToken(token)
      navigate('/dashboard')
    } catch (err) {
      setError('No fue posible iniciar sesión: ' + err.message)
    }
  }

  return (
    <article style={{maxWidth:'520px', margin:'10vh auto'}}>
      <header><h2>Iniciar sesión</h2></header>
      <form onSubmit={onSubmit}>
        <label>Usuario
          <input type="text" placeholder="email o usuario" autoComplete="username"
                 value={username} onChange={(e)=>setUsername(e.target.value)} required />
        </label>
        <label>Contraseña
          <input type="password" autoComplete="current-password"
                 value={password} onChange={(e)=>setPassword(e.target.value)} required />
        </label>
        <button type="submit">Entrar</button>
      </form>
      {error && <div className="error" style={{marginTop:'1rem'}}>{error}</div>}
      <footer className="right">
        <small className="badge">El token se almacena en localStorage</small>
      </footer>
    </article>
  )
}
